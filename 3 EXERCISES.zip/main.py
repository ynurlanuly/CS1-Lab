# EXERCISE 1

print("Hello World!")
print("Hello Again")
print("I like typing this.")
print("This is fun")
print('Yay! Printing.')
print("I'd much rather you 'not.")
print('I "said" do not touch this.')



# EXERCISE 2 

# A comment, this is so you can read your program later.
# Anything after the # is ignored by python. 

print("I could have code like this.") # and the comment after is ignored

# You can also use a comment to "disable" or comment out a piece of code:
# print("This won't run.")

print("This will run.")


# EXERCISE 3

print("I will now count my chickens:")
print("Hens", 25+30/6)
print("Roosters", 100-25*3%4)
print("Now I will count the eggs:")
print(3+2+1-5+4%2-1/4+6) 
print("It is true that 3+2 < 5-7?")
print(3+2 < 5-7)
print("What is 3+2?", 3+2)
print("What is 5-7?", 5-7)
print("Oh, that's why it's False")
print("How about some more")
print("Is it greater?", 5 > -2)
print("Is it greater or equal?", 5 >= -2)
print("Is it less or equal?", 5 <= -2)